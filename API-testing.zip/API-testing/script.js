console.log("script.js loaded")



let importFunctionsFromAPI = (names,defaultParas) =>{
  let lambdas = _.map(names, (fn) => {
      return (json) => {
        window.webkit.messageHandlers[fn].postMessage(json || defaultParas[fn] || {});
    }
  })
  return _.object(names, lambdas)
}

let importCallbacksFromAPI = (names) =>{
  let lambdas = _.map(names, (fn) => {
      return (json) => {
        console.log("CALLBACK FROM SWIFT: "+ fn + " is invoked")
        console.log("with parameter: " + JSON.stringify(json))
    }
  })
  return _.object(names, lambdas)
}

let makeButtons = (names, defaultPara) => {
  return _.reduce(_.map(names, (fn) => {
    return '<button onclick="window.functions.'+fn+'()"> ' + fn + ' </button><br/><br/>'
  }), (a,b) => a + b, "<br/><br/>")
}

window.init = (fns,cbs) =>{

  var defaultParas = {}

  addSpecialCases(defaultParas)

  window.functions = importFunctionsFromAPI(fns, defaultParas)

  window.swift = importCallbacksFromAPI(cbs)

  document.getElementsByTagName("body")[0].innerHTML = makeButtons(fns, defaultParas)
}

let addSpecialCases = (fnsAndPara) => {
  fnsAndPara["retrieveKioskZipFileAndInitAttendeeWebView"] = {zipFileName: "API-testing.zip", zipFileRemoteURL: "https://transfer.sh/TvvT0/API-testing.zip"}

  fnsAndPara["makeCSVAndOpenMailComposer"] = {
    "json": [{h1:1},{h2:1},{h3:2},{h4:3},{h1:5},{h2:7},{h3:12},{h4:19}],
    "csvHeader": ["h1","h2","h3","h4"],
    "emailAddressToSendTo": "a@0a.io"
  }

  fnsAndPara["openCameraViewForQRScanning"] ={
    "x": 20,
    "y": 20,
    "width": 100,
    "height": 250
  }

  fnsAndPara["sendBluetoothSignalToActivateRelay"] ={
    "channel": 1
  }
  fnsAndPara["sendBluetoothSignalToDeactivateRelay"] ={
    "channel": 5
  }
  fnsAndPara["printPDF"] ={
    "pdfURL": "https://community.mega.com/mega/attachments/mega/legal/11/6/MIT%20license.pdf"
  }
  fnsAndPara["readyDeviceForP2PConnectionWithVideoFeedScreen"] = {
    "deviceUUID": "testing",
    "x": 20,
    "y": 20,
    "width": 100,
    "height": 250
  }
}

window.webkit.messageHandlers.makeButtonsForTesting.postMessage({});
